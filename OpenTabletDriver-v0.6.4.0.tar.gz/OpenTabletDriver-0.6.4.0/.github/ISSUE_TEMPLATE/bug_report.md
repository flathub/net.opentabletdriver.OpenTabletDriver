---
name: Bug Report
about: Create a bug report to help fix issues with OpenTabletDriver
title: ''
labels: 'bug'
assignees: ''
---

## Description
<!-- Describe the issue below -->

## System Information:
<!-- Please fill out this information -->
| Name             | Value |
| ---------------- | ----- |
| Operating System         |
| OpenTabletDriver Version |
| Tablet                   |
