---
name: Configuration Request
about: Request for a new tablet to be added
title: 'Add support for '
labels: 'configuration'
assignees: ''
---

# Tablet Information
<!-- Include all of this information -->
<!-- Most of this can be found on the product page -->
<!-- If you can't find some of the information, leave it blank. -->
| Name            | Value |
| --------------- | ----- |
| Manufacturer    |
| Product Name    |
| Width           |
| Height          |
| Pressure Levels |
| LPI             |

## Diagnostic Information
<!-- Export diagnostics and attach or paste below -->
<!-- In the GUI, click Help -> Export Diagnostics -->

