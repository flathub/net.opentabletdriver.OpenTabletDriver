namespace OpenTabletDriver.Native.OSX.Input
{
    public enum CGEventTapLocation
    {
        kCGHIDEventTap = 0,
        kCGSessionEventTap = 1,
        kCGAnnotatedSessionEventTap = 2
    }
}
