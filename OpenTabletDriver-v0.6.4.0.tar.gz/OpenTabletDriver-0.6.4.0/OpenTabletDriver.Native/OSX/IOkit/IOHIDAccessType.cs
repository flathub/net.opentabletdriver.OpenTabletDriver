﻿using System;
namespace OpenTabletDriver.Native.OSX.IOkit
{
    public enum IOHIDAccessType
    {
        kIOHIDAccessTypeGranted = 0,
        kIOHIDAccessTypeDenied = 1,
        kIOHIDAccessTypeUnknown = 2
    }
}

