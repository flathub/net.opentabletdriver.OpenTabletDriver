namespace OpenTabletDriver.Native.Linux.Timers
{
    public enum TimerFlag
    {
        Default,
        AbsoluteTime
    }
}
