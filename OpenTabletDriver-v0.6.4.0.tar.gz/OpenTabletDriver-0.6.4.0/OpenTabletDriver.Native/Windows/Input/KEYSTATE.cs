namespace OpenTabletDriver.Native.Windows.Input
{
    public enum KEYSTATE : int
    {
        KEY_TOGGLED = 0x1,
        KEY_PRESSED = 0x8000
    }
}
