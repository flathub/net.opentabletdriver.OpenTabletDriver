namespace OpenTabletDriver.Native.Windows.CM
{
    public enum CM_NOTIFY_FILTER_FLAG
    {
        DEFAULT,
        ALL_INTERFACE_CLASSES,
        ALL_DEVICE_INSTANCES
    }
}
